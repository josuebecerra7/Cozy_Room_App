// In this file we will add the JS functions for the frontent
$( document ).ready(function() {



})